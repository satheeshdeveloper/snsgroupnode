// Import Joi for schema validation
const Joi = require('joi');


// Define schema for validating an entire card
const cartSchema = Joi.object({
  
  // 'customer_id' must be a string, alphanumeric, exactly 24 characters long (common for MongoDB ObjectId), and is required
  customer_id: Joi.string().alphanum().length(24).required(),

  // 'product_id' must be a string, alphanumeric, exactly 24 characters long (common for MongoDB ObjectId), and is required
  product_id: Joi.string().alphanum().length(24).required(),
  
  // 'quantity' must be an integer, greater than or equal to 1 (positive integer), and is required
  quantity: Joi.number().integer().min(1).required(),

});


// Export the schemas for use in other parts of the application
module.exports = { cartSchema};
