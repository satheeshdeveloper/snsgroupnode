module.exports={
    success_message:"success",
    error_message: 'error',
    user_created:'user created successfully',
    order_created:"order created successfully",
    product_created:"product created successfully",
    cart_created: 'product added to cart successfully',
    user_not_exist:"user does not exist.",
    product_out_of_stack:"some products are out of stock.please review your order",
    product_not_exist:"some products do not exist.please review your order"
}   
