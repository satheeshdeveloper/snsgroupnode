/* Usage:
* Import this module into the controller to access the service functions
* and perform operations on cart data.
*/

// Import required modules
const Cart=require("../models/cart")
const mongoose = require('mongoose');
const config=require('../config');

// Function to create a new order
const createCart=async(customer_id,product_id,quantity)=>{
    try {        
       const cart= await Cart.create({
            customer_id,
            product_id,
            quantity
        })
        return {status:config.success_message,data:cart }
    } catch (error) {
        return {status:config.error_message,message:error}
    }
}

// Function to get details of a specific order
const getCartDetails=async(customer_id)=>{
 try {
      const cartDetails = await Cart.aggregate([
        {
          $match: {
            customer_id: new mongoose.Types.ObjectId(customer_id), 
          },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'customer_id',
            foreignField: '_id',
            as: 'userResults',
          },
        },
        {
          $lookup: {
            from: 'products',
            localField: 'product_id',
            foreignField: '_id',
            as: 'productResults',
          },
        },
        {
          $project: {
            _id: 1,
            customer: {
              customer_id: { $arrayElemAt: ['$userResults._id', 0] },
              name: { $arrayElemAt: ['$userResults.name', 0] },
              email: { $arrayElemAt: ['$userResults.email', 0] },
              address: { $arrayElemAt: ['$userResults.address', 0] },
            },
            product: {
              name: { $arrayElemAt: ['$productResults.name', 0] },
              product_id: { $arrayElemAt: ['$productResults._id', 0] },
              price: { $arrayElemAt: ['$productResults.price', 0] },
              category: { $arrayElemAt: ['$productResults.category', 0] },
            },
          },
        },
      ]);
      
      
    return {status:config.success_message,data:cartDetails }

  } catch (error) {
    return {status:config.error_message,message:error}
  }
    
}


// Export functions 
module.exports={
    createCart,
    getCartDetails
}