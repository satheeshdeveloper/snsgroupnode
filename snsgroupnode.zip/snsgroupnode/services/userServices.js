/* Usage:
* Import this module into the controller to access the service functions
* and perform operations on customer data.
*/



// Import required modules
const User=require("../models/user")
const config=require('../config');

// Function to create a new user
const createUser=async(name,email, hashedPassword, street, city,state ,zip_code)=>{    
    try {        
       const user=  await User.create({
        name,
        email,
        password: hashedPassword,
        address:{
            street,
            city,
            state,
            zip_code
        }     
    })
        return {status:config.success_message,data:user }
    } catch (error) {
        return {status:config.error_message,message:error}
    }
}

// Function to get a specific customer by ID
const getUser=async(id)=>{
    try {
        const customer = await User.findById(id)
        return {status:config.success_message,data:customer }

    } catch (error) {
        return {status:config.error_message,message:error}
    }
}

// Export functions
module.exports={
    createUser,
    getUser,
}