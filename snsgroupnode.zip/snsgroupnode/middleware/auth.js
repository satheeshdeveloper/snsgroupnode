const jwt = require('jsonwebtoken');

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader; // Extract the token from "Bearer TOKEN"
  if (token == null) {
    return res.sendStatus(401); // Unauthorized
  }

  jwt.verify(token, 'your_jwt_secret', (err, user) => {
    if (err) {
      return res.sendStatus(403); // Forbidden
    }
    
    req.user = user; // Attach user info to the request object
    next(); // Proceed to the next middleware or route handler
  });
}

module.exports = { authenticateToken };
