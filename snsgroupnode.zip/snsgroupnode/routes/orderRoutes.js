//  Sets up routes for managing orders.
// Import dependencies

const express = require('express');
const router = express.Router();
const orderController=require("../controllers/orderController");
const { authenticateToken } = require('../middleware/auth'); // Adjust the path as needed


// Set up routes for order management
router.post("/create",authenticateToken,orderController.createOrder);
router.get("/get/:order_id",authenticateToken,orderController.getOrderDetails)
router.get("/list/:customer_id",authenticateToken,orderController.listOrders)
router.get("/total_sales",authenticateToken,orderController.calculateTotalSales)
router.get("/popular",authenticateToken,orderController.popularProduct)

// Export router
module.exports=router
