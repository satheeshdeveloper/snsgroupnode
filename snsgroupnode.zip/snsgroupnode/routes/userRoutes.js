// Sets up routes for handling customer-related HTTP requests.
// Import dependencies

const express = require('express');
const router = express.Router();
const userController=require("../controllers/userController");

// Set up route for customer creation
router.post("/create",userController.createUser)
router.post("/signin",userController.singin)


// Export router
module.exports=router