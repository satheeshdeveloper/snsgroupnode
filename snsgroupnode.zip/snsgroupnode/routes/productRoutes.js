//Sets up routes for managing products.

// Import dependencies
const express = require('express');
const router = express.Router();
const productController=require("../controllers/productController");
const { authenticateToken } = require('../middleware/auth'); // Adjust the path as needed

// Set up route for product creation
router.post("/create", authenticateToken, productController.createProduct);
router.get("/list", authenticateToken, productController.listProduct)

// Export router
module.exports=router