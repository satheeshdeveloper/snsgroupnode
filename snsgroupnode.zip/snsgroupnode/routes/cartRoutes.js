const express = require('express');
const router = express.Router();
const cartController=require("../controllers/cartController");
const { authenticateToken } = require('../middleware/auth'); // Adjust the path as needed


// Set up routes for cart management
router.post("/create",authenticateToken,cartController.createCart);
router.get("/list/:customer_id",authenticateToken,cartController.listCart)

// Export router
module.exports=router
