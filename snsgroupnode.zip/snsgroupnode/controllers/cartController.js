/* Usage:
 * Import this module into the routing layer to use these functions as
 * handlers for various HTTP routes related to cart operations.
 */
// Import dependencies
const config =require('../config')
const {cartSchema} =require('../validators/cartValidator')
const cartService=require('../services/cartServices')
const {customerIdSchema}=require("../validators/orderValidator")


// Function to create a cart
const createCart=async(req,res)=>{
    try {        
        const { error } = cartSchema.validate(req.body);
  
    if (error) {
    return res.status(400).json({ error: error.details[0].message });
    }
       const {customer_id,product_id,quantity}=req.body;

       const product=await cartService.createCart(customer_id,product_id,quantity)
        
       if(product.status== config.success_message){
        return res.status(201).json({
            status:config.success_message,
            message:config.cart_created
        })
       }else{
        return res.status(400).json({
            status:config.error_message,
            message:product.message
        })
       }
    } catch (error) {
        return res.status(500).json({
            status:config.error_message,
            message:error
        })
    }
}

// Function to list all orders for a specific customer
const listCart=async(req,res)=>{
    try {
        const { error } = customerIdSchema.validate(req.params);
  
        if (error) {
          return res.status(400).json({ error: error.details[0].message });
        }
        const {customer_id}=req.params;
        const listOrders= await cartService.getCartDetails(customer_id)
         
        if(listOrders.status== config.success_message){
            return res.status(200).json({
                status:config.success_message,
                data:listOrders.data
            })
           }else{
            
            return res.status(500).json({
                status:config.error_message,
                message:customer.message
            })
           }
    } catch (error) {
        return res.status(500).json({
            status:config.error_message,
            message:error
        })
    }
   
}


// Export functions 
module.exports={
    createCart,
    listCart
}