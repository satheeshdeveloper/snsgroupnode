/* Usage:
 * Import this module into the routing layer to use these functions as
 * handlers for various HTTP routes related to user operations.
 */


const config=require('../config')
const userServices=require("../services/userServices")
const userValidator=require("../validators/userValidator")
const bcrypt = require('bcrypt');
const User=require("../models/user")
const jwt = require('jsonwebtoken');


//create new user
const createUser=async(req,res)=>{
    try {
        const { error } = userValidator.validate(req.body);
  
        if (error) {
          return res.status(400).json({ error: error.details[0].message });
        }
        const {name,email,address,password}=req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user= await userServices.createUser(name,email, hashedPassword, address.street, address.city,address.state ,address.zip_code)
         
        if(user.status== config.success_message){
            return res.status(201).json({
                status:config.success_message,
                message:config.user_created
            })
           }else{
            
            return res.status(500).json({
                status:config.error_message,
                message:user.message
            })
           }
    } catch (error) {
        return res.status(500).json({
            status:config.error_message,
            message:error
        })
    }
   
}

const singin=async(req,res)=>{
    try { 
    const {email,password} = req.body;  
   
    // Find the user by email
    const user = await User.findOne({ email });
     console.log("user",user);
    if (!user) {
      throw new Error('User not found');
    }

    // Check if the password is correct
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      throw new Error('Invalid password');
    }

    // Generate a JWT token
    const token = jwt.sign(
      { userId: user._id },
      'your_jwt_secret', // Replace with your actual secret key
      { expiresIn: '1h' } // Token expiration time
    );

    return res.status(200).json({ token, user });
    }catch(error){
       throw new Error('Error signing in user: ' + error.message);
    }
}


module.exports={
    createUser,
    singin
}