/**
 * Defines the Mongoose schema and model for customer documents.
 */
// Import mongoose
const mongoose = require('mongoose');

// Define the customer schema
const userSchema = new mongoose.Schema({

  name: {
      type: String,
      required: true
  },
  email: {
      type: String,
      required: true,
      unique:true
  },
  password: {
    type: String,
    required: true
  },
  address: {
      street: {
          type: String,
          required: true
      },
      city: {
          type: String,
          required: true
      },
      state: {
          type: String,
          required: true
      },
      zip_code:   
      {
          type: String,
          required: true
      }
  },
  role: {
    type: String,
    required: false,
    default: "user"
  }
});

// Create and export the Customer model
const User = mongoose.model('User', userSchema);
module.exports = User;
