/* * Defines the Mongoose schema and model for cart documents.*/
// Import mongoose
const mongoose = require('mongoose');

// Define the order schema
const cartSchema = new mongoose.Schema({
    customer_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    product_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    quantity: {
         type: Number,
         required: true
    }
});

// Create and export the Order model
module.exports = mongoose.model('Cart', cartSchema);   

